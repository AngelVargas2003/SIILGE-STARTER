import Vue from 'vue'
import { abilitiesPlugin } from '@casl/vue'
import ability from './ability'

Vue.use(abilitiesPlugin, ability)
