export const initialAbility = [
  {
    action: 'read',
    subject: 'Public',
  },
]

export const _ = undefined
