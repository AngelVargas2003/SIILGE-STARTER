require('./src/main.js')
